self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "c6dd13d1cd7085730da345191039590f",
    "url": "/corona/index.html"
  },
  {
    "revision": "5619b02edd00e9b597e6",
    "url": "/corona/static/css/main.84309f43.chunk.css"
  },
  {
    "revision": "f00df3a81b3f578841ed",
    "url": "/corona/static/js/2.6a7912d6.chunk.js"
  },
  {
    "revision": "176852ae27885dfd7559e0fb4b332d24",
    "url": "/corona/static/js/2.6a7912d6.chunk.js.LICENSE.txt"
  },
  {
    "revision": "5619b02edd00e9b597e6",
    "url": "/corona/static/js/main.33321da1.chunk.js"
  },
  {
    "revision": "2e7e34a7e5a1c99750ce",
    "url": "/corona/static/js/runtime-main.2fd64bf6.js"
  }
]);
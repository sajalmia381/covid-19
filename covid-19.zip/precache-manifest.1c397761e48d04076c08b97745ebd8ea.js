self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "eefc5daa0a85a68ca91c62fbc14324fc",
    "url": "/corona/index.html"
  },
  {
    "revision": "033540e15842c829f8a5",
    "url": "/corona/static/css/main.3a6be3cf.chunk.css"
  },
  {
    "revision": "01e6d754fa1d6be8f7b7",
    "url": "/corona/static/js/2.d00ba796.chunk.js"
  },
  {
    "revision": "176852ae27885dfd7559e0fb4b332d24",
    "url": "/corona/static/js/2.d00ba796.chunk.js.LICENSE.txt"
  },
  {
    "revision": "033540e15842c829f8a5",
    "url": "/corona/static/js/main.20daa301.chunk.js"
  },
  {
    "revision": "2e7e34a7e5a1c99750ce",
    "url": "/corona/static/js/runtime-main.2fd64bf6.js"
  }
]);